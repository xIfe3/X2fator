export class Notification {}
